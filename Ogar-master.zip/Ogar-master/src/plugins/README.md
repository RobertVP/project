This is where you put your plugins. Put them under a folder with lowercase letters on, which includesindex.js with a structure similar to the example plugin. Open `options.ini` and read the comments to enable the plugin on server start.

Currently the API supports only adding commands and gamemodes. Further code injection (custom properties, tweaking, on update call) requires server code manipulation.
